//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'https://www.bol.com/nl/nl/'", "snapshot=Action_1.inf");
	truclient_step("2", "Click on Alles accepteren button", "snapshot=Action_2.inf");
	truclient_step("4", "Click on Zoeken textbox", "snapshot=Action_4.inf");
	truclient_step("5", "Type warehouse in Zoeken textbox", "snapshot=Action_5.inf");
	truclient_step("6", "Press key Enter on Zoeken textbox", "snapshot=Action_6.inf");
	truclient_step("7", "Get Visible Text from GetResultsNumber", "snapshot=Action_7.inf");
	truclient_step("8", "Evaluate JavaScript code ResultsNumber = ResultsN... ResultsNumber);", "snapshot=Action_8.inf");
	truclient_step("9", "Click on Open_First_Product link", "snapshot=Action_9.inf");
	truclient_step("10", "Click on Terug Terug JavaScript link", "snapshot=Action_10.inf");
	truclient_step("11", "Click on Open_Random_Product link", "snapshot=Action_11.inf");

	return 0;
}
